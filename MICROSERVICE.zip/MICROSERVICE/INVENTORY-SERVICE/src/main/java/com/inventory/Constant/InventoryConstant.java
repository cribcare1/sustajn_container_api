package com.inventory.Constant;

public class InventoryConstant {
    public static  final String ACTIVE="active";
    public static  final String INACTIVE="inactive";
    public static final String STATUS="status";
    public  static  final String MESSAGE="message";
    public static final  String INVENTORY_MASTER_DATA="inventoryMasterData";
    public static final String SUCCESS = "success";
    public static final String ERROR = "error";

}
