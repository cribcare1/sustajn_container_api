package com.inventory.repository;

import com.inventory.entity.AdminInventoryMasterAudit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminInventoryMasterAuditRepository extends JpaRepository<AdminInventoryMasterAudit,Long> {
}
