package com.auth.enumDetails;

public enum UserType {
    USER,
    RESTAURANT,
    ADMIN
}
