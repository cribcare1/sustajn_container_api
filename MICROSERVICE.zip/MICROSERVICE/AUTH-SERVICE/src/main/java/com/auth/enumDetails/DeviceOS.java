package com.auth.enumDetails;

public enum DeviceOS {
    IOS,
    ANDROID,
    WEB
}
