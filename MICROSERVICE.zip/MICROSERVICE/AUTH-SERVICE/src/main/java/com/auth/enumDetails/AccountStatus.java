package com.auth.enumDetails;

public enum AccountStatus {
    active,
    inactive,
    suspended
}