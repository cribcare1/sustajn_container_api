package com.auth.enumDetails;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
